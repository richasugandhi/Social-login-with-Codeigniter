UIKit Starter template
==
This example, Starter template, is modelled upon Bootstrap's which can be found here: http://getbootstrap.com/2.3.2/examples/starter-template.html
It's the most basic template, and makes use of the off-canvas navigation for a mobile navigational menu.

Example
---
An example can be found at: http://nands.github.io/uikit-starter-template/

Why
---
The idea behind this(and other uikit-*) repositories is to act as a comparison between UIKit and Bootstrap with regards to looks and design, functionality and markup.
Additionallity, it also serves as a quick baseline comparison of how both frameworks appear visually.