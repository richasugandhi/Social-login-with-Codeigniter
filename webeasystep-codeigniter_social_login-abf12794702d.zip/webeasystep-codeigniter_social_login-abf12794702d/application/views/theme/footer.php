</div><!-- /.container -->
<script type="text/javascript">
var infolinks_pid = 2803170;
var infolinks_wsid = 0;
</script>
<script type="text/javascript" src="//resources.infolinks.com/js/infolinks_main.js"></script>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://www.atlasestateagents.co.uk/javascript/tether.min.js"></script><!-- Tether for Bootstrap -->
<script>window.jQuery || document.write('<script src="<?= base_url()?>global/bootstrap/assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="<?= base_url()?>global/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
<script src="<?= base_url()?>global/bootstrap/assets/js/ie10-viewport-bug-workaround.js"></script>
</body>
</html>
