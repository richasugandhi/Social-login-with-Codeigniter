<?php
//////////Modules/////////////////////// tabs name
$lang['home'] 	  = 'Home';
$lang['sound'] 	  = 'Sounds';
$lang['video'] 	  = 'Videos';
$lang['pages']    = "Extera pages";
$lang['news']     = "News";
$lang['photos']   ="Photo galary";
$lang['articles'] ="Articles";
$lang['navigation'] ="Navigation";
$lang['contactus'] ="Contact us";
$lang['visitors'] ="Visitors";
$lang['book'] ="E-book Library";
$lang['public_trips'] = "Public trips";