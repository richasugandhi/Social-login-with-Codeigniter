<?php
$lang['unreaded_payments']    = "عمليات دفع لم تشاهد بعد";
$lang['adminPages']    = "الصفحات الإضافية";
$lang['adminContactus'] ="إدارة الرسائل";
$lang['adminNews'] ="إدارة الأخبار";
$lang['adminPartitions'] =" إدارة السلع";
$lang['adminVoting'] ="إدارة الاستطلاعات";
$lang['adminMailinglist'] ="إدارة القائمة البريدية";
$lang['adminTutorials'] ="إدارة الشروحات";
$lang['adminSecThoughts'] ="إدارة خواطر أمنية";
$lang['adminUsers'] ="إدارة المستخدمين و الصلاحيات";
$lang['adminTeamSite'] ="إدارة فريق الموقع";
$lang['adminCars'] = 'إدارة سيارات الخدمة';
$lang['adminPlaces'] = 'إدارة الأماكن';
$lang['adminServices'] = 'إدارة الخدمات';
$lang['adminContract_plan'] = 'إدارة خطط التعاقد';

$lang['adminArticles'] = "إدارة المقالات و الأبحاث";
$lang['adminVideo'] = "إدارة المرئيات";
$lang['adminPhotos'] = "إدارة الصور";
$lang['adminsound'] = "إدارة الصوتيات";
$lang['adminBooks'] = "إدارة المكتبة الإلكترونية";
$lang['adminAds'] = "إدارة الاعلانات";
$lang['website'] = "زيارة الموقع";

$lang['unreaded_comments'] = "تعليقات لم تقرأ بعد";
$lang['unread_messages'] = "رسايل لم تقرأ بعد";
$lang['welcome'] = "مرحبا بك يا";
$lang['logout'] = "خروج";
$lang['setting'] = "إعدادات الموقع";




$lang['manage_back_end'] = "لوحة التحكم";
$lang['visite_website'] =  'زيارة الموقع';