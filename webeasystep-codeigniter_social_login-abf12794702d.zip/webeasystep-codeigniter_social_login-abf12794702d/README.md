in this script we use HybridAuth  to login with many providers like Facebook,google,twitter with codeigniter
we also keep in mind popular errors like twitter error 
The client application failed validation: Not a valid URL format
and error "redirect_uri_mismatch" in google API
just follow steps and all we be good

see full tutorial here [codeigniter social login](http://webeasystep.com/blog/view_article/Social_Logins_in_codeigniter_with_HybridAuth_easy_steps)